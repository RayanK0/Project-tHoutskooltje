<?php
$servername = "localhost"; 
$username = "root";    
$password = "rayan";   
$database = "thoutskooltje";     
$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT * FROM bestellingen";

$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Bestellingen</title>
</head>
<body>
    <h1>Alle Bestellingen</h1>
    <table border="1">
        <tr>
            <th>Voornaam</th>
            <th>Achternaam</th>
            <th>Telefoonnummer</th>
            <th>Aantal personen</th>
            <th>Type</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['Voornaam'] . "</td>";
                echo "<td>" . $row['Achternaam'] . "</td>";
                echo "<td>" . $row['Telefoonnummer'] . "</td>";
                echo "<td>" . $row['Aantal'] . "</td>";
                echo "<td>" . $row['Type'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Geen bestellingen gevonden</td></tr>";
        }
        ?>
    </table>
    <br>
    <h1>FAQ Aanpassen</h1>

<!-- Formulier om een nieuwe vraag toe te voegen -->
<form method="POST" action="faqachter.php">
    <label for="new_question">Nieuwe vraag:</label>
    <input type="text" id="new_question" name="new_question" required>
    <label for="new_answer">Antwoord:</label>
    <input type="text" id="new_answer" name="new_answer" required>
    <button type="submit" name="add_question">Vraag toevoegen</button>
</form>

<!-- Toon bestaande vragen uit de database -->
<?php
$sql = "SELECT * FROM faq";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

if ($result->num_rows > 0) {
    echo "<h2>Bestaande vragen:</h2>";
    echo "<ul>";
    while ($row = $result->fetch_assoc()) {
        echo "<li>";
        echo "<strong>Vraag:</strong> " . $row['vraag'] . "<br>";
        echo "<strong>Antwoord:</strong> " . $row['antwoord'];
        echo "<a href='faqachter.php?delete_id=" . $row['id'] . "'>Verwijderen</a>";
        echo "</li><br>";
    }
    echo "</ul>";
} else {
    echo "<p>Geen vragen gevonden.</p>";
}

?>
<a href="overons.html"><button>Ga terug</button></a>
</body>
</html>
