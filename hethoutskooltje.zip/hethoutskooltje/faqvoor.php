<!DOCTYPE html>
<html>
<head>
    <title>t'Houtskooltje - FAQ</title>
    <link rel="stylesheet" href="faq.css">
    <style>
        .faq-content {
            margin: 350px 20px 20px 50px; 
            padding: 20px;
            background-color: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 400px;
        }

        .faq-content ul {
            list-style: none;
            padding: 0;
        }

        .faq-content li {
            margin-bottom: 20px;
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 5px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            cursor: pointer; 
        }

        .faq-content li strong {
            font-weight: bold;
        }

        .faq-content li p {
            margin-top: 5px;
            display: none; 
        }

        .faq-content .no-questions {
            font-style: italic;
            color: #777;
        }
        .logo {
            position: absolute;
            top: 1%;
            width: 20%;
            height: 100px;
            left: 0%;
        }
    </style>
</head>
<body>
    
    <header>
        <button class="loginknop" onclick="location.href='login.html'">Log in</button>
        <button class="homeknop" onclick="location.href='overons.html'">Home</button>
        <button class="contact" onclick="location.href='contact.html'">Contact</button>
        <button class="faqknop" onclick="location.href='faqvoor.php'">FAQ</button>
    </header>
    <img src="fotos/pand.jpg" alt="pand" class="pand">
    <img src="fotos/logo.png" onclick="location.href='overons.html'" alt="logo1" class="logo">
    <hr style="border: 1px solid black; width: 100%; position: absolute; top: 11%">

    <div class="faq-content">
        <div class = faq><h1>FAQ</h1></div>
        <ul>
            <?php
            $servername = "localhost"; 
            $username = "root";    
            $password = "rayan";    
            $database = "thoutskooltje";    

            $conn = new mysqli($servername, $username, $password, $database);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT * FROM faq";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<li>";
                    echo '<strong>' . $row['vraag'] . '</strong>';
                    echo "<p style='display:none;'><strong></strong> " . $row['antwoord'] . "</p>";
                    echo "</li>";
                }
            } else {
                echo "<li class='no-questions'>Geen vragen gevonden.</li>";
            }

            $conn->close();
            ?>
        </ul>
    </div>





    
    <script>
        // Voeg JavaScript toe om het antwoord te tonen/verbergen bij klikken
        const questionItems = document.querySelectorAll('.faq-content li');
        questionItems.forEach(item => {
            item.addEventListener('click', () => {
                const answer = item.querySelector('p');
                if (answer.style.display === 'none' || answer.style.display === '') {
                    answer.style.display = 'block';
                } else {
                    answer.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
