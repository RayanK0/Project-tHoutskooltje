<?php
$servername = "localhost";
$username = "root"; 
$password = "rayan";   
$database = "thoutskooltje";    

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$bbq = ""; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vnaam = $_POST['voornaam'];
    $anaam = $_POST['achternaam'];
    $aantal = $_POST['aantal'];
    $tel = $_POST['telefoonnummer'];
    
    if (isset($_POST['bbq'])) {
        $bbq = $_POST['bbq'];
    }
    
    // Controleer of voornaam, achternaam en aantal niet leeg zijn
    if (!empty($tel) && !empty($vnaam) && !empty($anaam) && !empty($aantal) && !empty($bbq)) {
        $insert_sql = "INSERT INTO bestellingen (Voornaam, Achternaam, Telefoonnummer, Aantal, Type) 
                       VALUES ('$vnaam', '$anaam', '$tel', '$aantal', '$bbq')";
        
        if ($conn->query($insert_sql) === TRUE) {
            echo "Je bestelling is voltooid $vnaam $anaam!<br>";
            echo "Je hebt $aantal $bbq BBQ besteld!<br>";
        } else {
            echo "Error: " . $insert_sql . "<br>" . $conn->error;
        }
    } else {
        echo "Vul alle velden in!.<br>";
    }
} else {
    echo "Het formulier is nog niet verzonden";
}

$conn->close();

?>
<a href="overons.html"><button>Ga terug</button></a>
