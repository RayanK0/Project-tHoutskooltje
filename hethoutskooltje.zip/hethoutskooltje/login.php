<?php
session_start();


if (isset($_POST['gebruikersnaam']) && isset($_POST['wachtwoord'])) 
{
    if($_POST['wachtwoord'] == "werknemer")
    {
        header("Location: werknemer.php");
        exit(); 
    }

    if($_POST['wachtwoord'] != "werknemer")
    {
        echo "Fout wachtwoord";
    }
}
?>