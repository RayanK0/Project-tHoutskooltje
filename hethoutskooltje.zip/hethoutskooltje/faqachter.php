<?php
// Importeer de databaseverbinding uit werknemer.php
require_once('werknemer.php');
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Nieuwe vraag toevoegen
    if (isset($_POST['add_question'])) {
        $new_question = $_POST['new_question'];
        $new_answer = $_POST['new_answer'];

        // Voeg de nieuwe vraag toe aan de database
        $sql = "INSERT INTO faq (vraag, antwoord) VALUES ('$new_question', '$new_answer')";
        $conn->query($sql);
    }
}

// Een bestaande vraag verwijderen
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Verwijder de vraag uit de database
    $sql = "DELETE FROM faq WHERE id = $delete_id";
    $conn->query($sql);
}

// Terugkeren naar werknemer.php na voltooien van bewerkingen
header("Location: werknemer.php");
// Sluit de verbinding met de database nadat alle bewerkingen zijn voltooid
$conn->close();

?>
